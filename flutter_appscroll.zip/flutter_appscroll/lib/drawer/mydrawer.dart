import 'package:flutter/material.dart';
import 'package:flutter_appscroll/sayfalar/ListWheelScrollState.dart';
import 'package:flutter_appscroll/sayfalar/kategoriler.dart';
import 'package:flutter_appscroll/sayfalar/scrollsnaplist.dart';
import 'package:flutter_appscroll/sayfalar/sliderscroll.dart';
import 'package:flutter_appscroll/sayfalar/webview.dart';

class  mydrawer extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Drawer(
      child: ListView(
          children: <Widget>[
      UserAccountsDrawerHeader(
      accountEmail: Text("fatema.mams@gmail.com"),
      accountName: Text("firat.edu.tr"),
      currentAccountPicture: CircleAvatar(
          child: Icon(Icons.person, color: Colors.black87,)
      ),
      decoration: BoxDecoration(
        color: Colors.green.shade500,
      ),
    ),
    Container( child: FlatButton
    (onPressed: ()=>Navigator.pop(context),child: Text('Close', style: TextStyle(fontWeight: FontWeight.bold),),
    ),
    ),
            Divider(
              color: Colors.black.withOpacity(0.999999),
              height: 2
              ,),
            ListTile(
              title: Text("listviewCostum",
                  style: TextStyle(color: Colors.black,
                      fontStyle: (FontStyle.italic),
                      fontSize: 20)),
              leading: Icon(Icons.home),
              trailing: Icon(Icons.arrow_right),
              selected: true,
              onTap: () {
                Navigator.of(context).pushNamed('listviewCostum');
              },
            ),
            ListTile(
              title: Text("listWhellScrollState", style: TextStyle(color: Colors.black,
                  fontStyle: (FontStyle.italic),
                  fontSize: 20)),
              leading: Icon(Icons.calendar_today),
              trailing: Icon(Icons.arrow_right),
              selected: true,
              onTap: () {
                Navigator.of(context).pushNamed(" ListWheelScroll");
              },
            ),
            ListTile(
              title: Text("scrollsnaplis", style: TextStyle(color: Colors.black,
                  fontStyle: (FontStyle.italic),
                  fontSize: 20)),
              leading: Icon(Icons.add_to_home_screen,),
              trailing: Icon(Icons.arrow_right),
              selected: true,
              onTap: () {
                Navigator.of(context).pushNamed('scrollsnaplis');
              },
            ),
            ListTile(
              title: Text("ScrollablePositionedListPage", style: TextStyle(color: Colors.black,
                  fontStyle: (FontStyle.italic),
                  fontSize: 20)),
              leading: Icon(Icons.copyright,),
              trailing: Icon(Icons.arrow_right),
              subtitle: Text(' '),
              selected: true,

              onTap: () {
                Navigator.of(context).pushNamed('ScrollablePositionedListPage');
              },),
            ListTile(
              title: Text("scrolltoindex", style: TextStyle(color: Colors.black,
                  fontStyle: (FontStyle.italic),
                  fontSize: 20)),
              leading: Icon(Icons.share),
              trailing: Icon(Icons.arrow_right),
              selected: true,
              onTap: () {Navigator.of(context).pushNamed('scrolltoindex');},
            ),
            ListTile(
              title: Text("kategoriler", style: TextStyle(color: Colors.black,
                  fontStyle: (FontStyle.italic),
                  fontSize: 20)),
              selected: true,
              leading: Icon(Icons.category),
              trailing: Icon(Icons.arrow_right),
              onTap: () {Navigator.of(context).pushNamed('kategoriler');},
            ),
            ListTile(
              title: Text("LazyLoadingPage ", style: TextStyle(color: Colors.black,
                  fontStyle: (FontStyle.italic),
                  fontSize: 20)),
              selected: true,
              leading: Icon(Icons.category),
              trailing: Icon(Icons.arrow_right),
              onTap: () {Navigator.of(context).pushNamed('LazyLoadingPage');},
            ),
            ListTile(
              title: Text("listslide ", style: TextStyle(color: Colors.black,
                  fontStyle: (FontStyle.italic),
                  fontSize: 20)),
              selected: true,
              leading: Icon(Icons.category),
              trailing: Icon(Icons.arrow_right),
              onTap: () {Navigator.of(context).pushNamed('listslide');},
            ),
            ListTile(
              title: Text("MyWebView ", style: TextStyle(color: Colors.black,
                  fontStyle: (FontStyle.italic),
                  fontSize: 20)),
              selected: true,
              leading: Icon(Icons.category),
              trailing: Icon(Icons.arrow_right),
              onTap: () {Navigator.of(context).pushNamed('MyWebView');},
            ),
          ],


      ),

    );

  }

}
