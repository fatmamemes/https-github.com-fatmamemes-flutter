import 'package:flutter/material.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:flutter_appscroll/sayfalar/Home.dart';
import 'package:flutter_appscroll/drawer/mydrawer.dart';
class scrollsnaplis extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
return snapstat();
  }
}
class snapstat  extends State<scrollsnaplis>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return  Scaffold(

        backgroundColor: Colors.amber,
        appBar: AppBar(title: Text('snappingpageScroll'),

    ),
        body: SnappingPageScroll(
          viewportFraction: 0.75,
          children: <Widget>[
            customCard('Card 1'),
            customCard('Card 2'),
            customCard('Card 3'),
            customCard('Card 4'),
            customCard('Card 5'),
            customCard('Card 6'),
          ],
        )
        );
  }
  Widget customCard(String text) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 100, 20, 100),
      child: Card(
        child: Text(text),
      ),
    );
  }

  SnappingPageScroll({double viewportFraction, List<Widget> children}) {}




  }


