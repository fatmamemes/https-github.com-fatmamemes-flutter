import 'package:flutter/material.dart';
import 'package:flutter_appscroll/sayfalar/Home.dart';
import 'package:flutter_appscroll/drawer/mydrawer.dart';
class kategoriler extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}
class _MyHomePageState extends State<kategoriler> {
  final FixedExtentScrollController _controller = FixedExtentScrollController();
  List<Widget> listtiles = [
    ListTile(
      leading: Icon(Icons.portrait),

      title: Text("Portrait"),
      subtitle: Text("Beautiful View..!"),
      trailing: Icon(Icons.arrow_forward_ios),

    ),
    ListTile(
      leading: Icon(Icons.landscape),
      title: Text("LandScape"),
      subtitle: Text("Beautiful View..!"),
      trailing: Icon(Icons.remove),
    ),

    ListTile(
      leading: Icon(Icons.map),
      title: Text("calender"),
      subtitle: Text("takvim ..!"),
      trailing: Icon(Icons.perm_contact_calendar),


    ),



    ListTile(
      leading: Icon(Icons.list),
      title: Text("List Example"),
      subtitle: Text("List Wheel Scroll view .!"),
      trailing: Icon(Icons.cloud),
    ),

    InkWell( child:
    ListTile(
      leading: Icon(Icons.settings),
      title: Text("Settings"),
      subtitle: Text("Change the setting..!"),
      trailing: Icon(Icons.portrait),

    ),
    ),
    ListTile(
      leading: Icon(Icons.event),
      title: Text("Add data"),
      subtitle: Text("Data View..!"),
      trailing: Icon(Icons.add),

    ),
    ListTile(
      leading: Icon(Icons.email),
      title: Text("Email"),
      subtitle: Text("Check Email..!"),
      trailing: Icon(Icons.arrow_forward),
    ),
    ListTile(
      leading: Icon(Icons.games),
      title: Text("Games"),
      subtitle: Text("Play Games..!"),
      trailing: Icon(Icons.zoom_out_map),
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(" Kategoriler"),
        ),
        body: Center(
          child: ListWheelScrollView(
            controller: _controller,
            itemExtent: 80,
            magnification: 1.2,
            useMagnifier: true,
            squeeze: 1,
            physics: FixedExtentScrollPhysics(),
            children: listtiles, //List of widgets
          ),
        ));

  }
}


