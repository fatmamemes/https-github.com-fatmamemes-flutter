import 'package:flutter/material.dart';
import 'package:flutter_appscroll/sayfalar/Home.dart';
import 'package:flutter_appscroll/drawer/mydrawer.dart';
class listviewCostum extends StatefulWidget {

    @override

  State<StatefulWidget> createState() {
    // TODO: implement createState
    return scrollstate();


  }}
class scrollstate extends State<listviewCostum> {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    Widget column = Expanded(
      child: Column(
        // align the text to the left instead of centered
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Title', style: TextStyle(fontSize: 16),),
          Text('subtitle'),
        ],
      ),
    );

    return ListView.builder(
      itemBuilder: (context, index) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: <Widget>[
                column,
                column,
              ],
            ),
          ),
        );
      },
    );
  }
}
