import 'package:flutter/material.dart';
import 'package:flutter_appscroll/sayfalar/lazyloadingscroll.dart';
import 'package:marquee_widget/marquee_widget.dart';
import 'package:flutter_appscroll/drawer/mydrawer.dart';
import 'package:flutter_appscroll/sayfalar/Home.dart';
import 'package:flutter_appscroll/sayfalar/ListWheelScrollState.dart';
import 'package:flutter_appscroll/sayfalar/kategoriler.dart';
import 'package:flutter_appscroll/sayfalar/listviewCostum.dart';
import 'package:flutter_appscroll/sayfalar/scrollsnaplist.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:flutter_appscroll/sayfalar/scrolltoindex.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:flutter_appscroll/sayfalar/scrollablePositionList.dart';
import 'package:flutter_appscroll/sayfalar/sliderscroll.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter_appscroll/sayfalar/webview.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: "home",
        home: MyHomePage(),
        routes: {
          ' ListWheelScroll': (context) {
            return ListWheelScroll();
          },
          'kategoriler': (context) {
            return kategoriler();
          },
          'listviewCostum': (context) {
            return listviewCostum();
          },
          'scrollsnaplis': (context) {
            return scrollsnaplis();
          },
          'scrolltoindex':(context){
            return scrolltoindex();
          },
          'LazyLoadingPage':(context){
            return LazyLoadingPage();
          },
          'ScrollablePositionedListPage':(context){
            return ScrollablePositionedListPage();
          },
          'listslide':(context){
            return listslide();
          },
          'MyWebView':(context){
            return MyWebView();
          },
        }
    );
  }
}