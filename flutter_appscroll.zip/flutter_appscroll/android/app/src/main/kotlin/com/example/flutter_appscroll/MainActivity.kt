package com.example.flutter_appscroll

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
